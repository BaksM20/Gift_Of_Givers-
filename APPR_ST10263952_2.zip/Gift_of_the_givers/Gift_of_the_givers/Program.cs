using Gift_of_the_givers.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Gift_of_the_givers.Models;
using Microsoft.AspNetCore.Identity;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<GiftContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddDefaultIdentity<Gift_of_the_givers.Models.ApplicationUser>(options =>
{
    options.SignIn.RequireConfirmedAccount = false;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = false;
    options.Password.RequiredLength = 6;
}).AddEntityFrameworkStores<GiftContext>();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/Login";
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

// Initialize database (apply migrations or create schema)
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<GiftContext>();
    try
    {
        var pending = db.Database.GetPendingMigrations();
        if (pending != null && pending.Any())
        {
            db.Database.Migrate();
        }
        else
        {
            var created = db.Database.EnsureCreated();
            if (!created)
            {
                try
                {
                    var creator = db.GetService<IRelationalDatabaseCreator>();
                    creator.CreateTables();
                }
                catch
                {
                    // Tables may already exist or creation failed due to permissions
                }
            }
        }
    }
    catch
    {
        try
        {
            var creator = db.GetService<IRelationalDatabaseCreator>();
            creator.CreateTables();
        }
        catch
        {
            // swallow; startup will continue and errors will surface during requests
        }
    }
}

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

// Seed a test user to verify login flow if none exists
using (var scope2 = app.Services.CreateScope())
{
    try
    {
        var userManager = scope2.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
        if (!userManager.Users.Any())
        {
            var user = new ApplicationUser { Email = "testuser@example.com", UserName = "testuser@example.com" };
            var create = await userManager.CreateAsync(user, "Passw0rd!");
        }
    }
    catch { }
}

app.Run();
