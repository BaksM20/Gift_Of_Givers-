using Gift_of_the_givers.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_the_givers.Data
{
    public class GiftContext : IdentityDbContext<ApplicationUser>
    {
        public GiftContext(DbContextOptions<GiftContext> options)
            : base(options) { }

        public DbSet<Disaster> Disasters { get; set; }
        public DbSet<Resource> Resources { get; set; }
        public DbSet<Volunteer> Volunteers { get; set; }
        public DbSet<VolunteerTask> VolunteerTasks { get; set; }
        public DbSet<InvoiceDonation> InvoiceDonations { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Ensure ASP.NET Identity tables and keys are configured
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Disaster>(entity =>
            {
                entity.HasKey(d => d.DisasterID);
                entity.Property(d => d.Name).IsRequired().HasMaxLength(200);
                entity.Property(d => d.EmergencyType).HasMaxLength(100);
                entity.Property(d => d.Status).HasMaxLength(50);
                entity.Property(d => d.LocationCity).HasMaxLength(120);
                entity.Property(d => d.LocationRegion).HasMaxLength(120);
                entity.Property(d => d.LocationCountry).HasMaxLength(120);
            });

            modelBuilder.Entity<Resource>(entity =>
            {
                entity.HasKey(r => r.ResourceID);
                entity.Property(r => r.Name).IsRequired().HasMaxLength(200);
                entity.Property(r => r.Unit).HasMaxLength(50);
                entity.Property(r => r.Type).HasConversion<int>();
                entity.Property(r => r.ClothingSize).HasMaxLength(40);
                entity.Property(r => r.ClothingCategory).HasMaxLength(60);
                entity.Property(r => r.MedicationDosageForm).HasMaxLength(80);
                entity.Property(r => r.MedicationStrength).HasMaxLength(80);
                entity.HasOne(r => r.Disaster)
                      .WithMany()
                      .HasForeignKey(r => r.DisasterID)
                      .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<Volunteer>(entity =>
            {
                entity.HasKey(v => v.VolunteerID);
                entity.Property(v => v.FirstName).IsRequired().HasMaxLength(100);
                entity.Property(v => v.LastName).IsRequired().HasMaxLength(100);
                entity.Property(v => v.Email).HasMaxLength(256);
                entity.Property(v => v.Phone).HasMaxLength(50);
            });

            modelBuilder.Entity<VolunteerTask>(entity =>
            {
                entity.HasKey(t => t.VolunteerTaskID);
                entity.Property(t => t.Title).IsRequired().HasMaxLength(200);
                entity.Property(t => t.Description).HasMaxLength(2000);
                entity.Property(t => t.Status).HasConversion<int>();
                entity.HasOne(t => t.Volunteer)
                      .WithMany()
                      .HasForeignKey(t => t.VolunteerID)
                      .OnDelete(DeleteBehavior.SetNull);
            });

            modelBuilder.Entity<InvoiceDonation>(entity =>
            {
                entity.HasKey(i => i.InvoiceDonationID);
                entity.Property(i => i.DonorName).IsRequired().HasMaxLength(200);
                entity.Property(i => i.DonorEmail).HasMaxLength(256);
                entity.Property(i => i.InvoiceNumber).HasMaxLength(50);
                entity.Property(i => i.Amount).HasColumnType("decimal(18,2)");
                entity.Property(i => i.Currency).HasMaxLength(3);
                entity.Property(i => i.Notes).HasMaxLength(500);
            });
        }
    }
}


