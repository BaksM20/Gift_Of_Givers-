using Gift_of_the_givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Gift_of_the_givers.Data;

namespace Gift_of_the_givers.Controllers
{
    [Authorize]
    public class VolunteerController : Controller
    {
        private readonly GiftContext _context;

        public VolunteerController(GiftContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var items = _context.Volunteers.OrderByDescending(v => v.RegistrationDate).ToList();
            return View(items);
        }

        public IActionResult Details(int id)
        {
            var model = _context.Volunteers.FirstOrDefault(v => v.VolunteerID == id);
            if (model == null) return NotFound();
            return View(model);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(new Volunteer { RegistrationDate = DateTime.Today, IsActive = true });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Volunteer model)
        {
            if (!ModelState.IsValid) return View(model);
            _context.Volunteers.Add(model);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}



