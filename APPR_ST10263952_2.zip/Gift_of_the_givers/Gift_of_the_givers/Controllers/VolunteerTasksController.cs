using Gift_of_the_givers.Data;
using Gift_of_the_givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_the_givers.Controllers
{
    [Authorize]
    public class VolunteerTasksController : Controller
    {
        private readonly GiftContext _context;

        public VolunteerTasksController(GiftContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var items = _context.VolunteerTasks.Include(t => t.Volunteer)
                .OrderBy(t => t.Status).ThenBy(t => t.ScheduledAt).ToList();
            return View(items);
        }

        public IActionResult Details(int id)
        {
            var item = _context.VolunteerTasks.Include(t => t.Volunteer).FirstOrDefault(t => t.VolunteerTaskID == id);
            if (item == null) return NotFound();
            return View(item);
        }

        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.VolunteerOptions = new SelectList(_context.Volunteers.OrderBy(v => v.FirstName).ToList(), "VolunteerID", "FirstName");
            return View(new VolunteerTask { ScheduledAt = DateTime.Today });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(VolunteerTask model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.VolunteerOptions = new SelectList(_context.Volunteers.OrderBy(v => v.FirstName).ToList(), "VolunteerID", "FirstName");
                return View(model);
            }
            _context.VolunteerTasks.Add(model);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}








