using Gift_of_the_givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Gift_of_the_givers.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Gift_of_the_givers.Controllers
{
    [Authorize]
    public class ResourceController : Controller
    {
        private readonly GiftContext _context;

        public ResourceController(GiftContext context)
        {
            _context = context;
        }

        public IActionResult Index(int? disasterId = null)
        {
            var query = _context.Resources
                .Include(r => r.Disaster)
                .AsQueryable();

            if (disasterId.HasValue)
            {
                query = query.Where(r => r.DisasterID == disasterId.Value);
            }

            var items = query.OrderByDescending(r => r.DonationReceivedDate).ToList();
            ViewBag.DisasterFilter = disasterId;
            ViewBag.DisasterOptions = new SelectList(_context.Disasters.OrderByDescending(d => d.StartDate).ToList(), "DisasterID", "Name", disasterId);
            return View(items);
        }

        public IActionResult Details(int id)
        {
            var item = _context.Resources.Include(r => r.Disaster).FirstOrDefault(r => r.ResourceID == id);
            if (item == null) return NotFound();
            return View(item);
        }

        [HttpGet]
        public IActionResult Create(int? disasterId = null)
        {
            var disasters = _context.Disasters.OrderByDescending(d => d.StartDate).ToList();
            if (disasters.Count == 0)
            {
                TempData["Message"] = "Please create a disaster before adding resources.";
                return RedirectToAction("Create", "Disaster");
            }
            ViewBag.DisasterOptions = new SelectList(disasters, "DisasterID", "Name", disasterId);
            ViewBag.HasDisasters = true;
            return View(new Resource { DonationReceivedDate = DateTime.Today, DisasterID = disasterId ?? 0 });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Resource model, int? disasterId)
        {
            // Try to recover DisasterID from posted form value when binding fails
            if (!model.DisasterID.HasValue || model.DisasterID.Value <= 0)
            {
                var posted = Request?.Form["DisasterID"].ToString();
                if (int.TryParse(posted, out var parsed))
                {
                    model.DisasterID = parsed;
                }
            }

            if ((!model.DisasterID.HasValue || model.DisasterID.Value <= 0) && disasterId.HasValue)
            {
                model.DisasterID = disasterId.Value;
            }
            // Server-side guard: disaster must be selected
            if (!model.DisasterID.HasValue || model.DisasterID.Value <= 0)
            {
                ModelState.AddModelError("DisasterID", "Please select a disaster.");
            }

            if (!ModelState.IsValid)
            {
                // Clear and re-validate after potential correction
                ModelState.Clear();
                TryValidateModel(model);
            }

            if (!ModelState.IsValid)
            {
                var disasters = _context.Disasters.OrderByDescending(d => d.StartDate).ToList();
                ViewBag.DisasterOptions = new SelectList(disasters, "DisasterID", "Name", model.DisasterID);
                ViewBag.HasDisasters = disasters.Count > 0;
                return View(model);
            }
            _context.Resources.Add(model);
            _context.SaveChanges();
            TempData["Message"] = "Resource saved successfully.";
            return RedirectToAction(nameof(Details), new { id = model.ResourceID });
        }
    }
}



