using Gift_of_the_givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Gift_of_the_givers.Data;
using Microsoft.EntityFrameworkCore;

namespace Gift_of_the_givers.Controllers
{
    [Authorize]
    public class DisasterController : Controller
    {
        private readonly GiftContext _context;

        public DisasterController(GiftContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var items = _context.Disasters.OrderByDescending(d => d.StartDate).ToList();
            return View(items);
        }

        public IActionResult Details(int id)
        {
            var model = _context.Disasters.FirstOrDefault(d => d.DisasterID == id);
            if (model == null) return NotFound();
            return View(model);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(new Disaster { StartDate = DateTime.Today, ReportedDate = DateTime.Today });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Disaster model)
        {
            if (!ModelState.IsValid) return View(model);
            _context.Disasters.Add(model);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}



