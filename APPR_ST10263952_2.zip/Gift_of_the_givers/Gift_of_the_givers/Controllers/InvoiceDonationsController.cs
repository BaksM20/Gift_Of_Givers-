using Gift_of_the_givers.Data;
using Gift_of_the_givers.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Gift_of_the_givers.Controllers
{
    [Authorize]
    public class InvoiceDonationsController : Controller
    {
        private readonly GiftContext _context;

        public InvoiceDonationsController(GiftContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var items = _context.InvoiceDonations.OrderByDescending(i => i.InvoiceDate).ToList();
            return View(items);
        }

        public IActionResult Details(int id)
        {
            var item = _context.InvoiceDonations.FirstOrDefault(i => i.InvoiceDonationID == id);
            if (item == null) return NotFound();
            return View(item);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(new InvoiceDonation { InvoiceDate = DateTime.Today, Currency = "ZAR" });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(InvoiceDonation model)
        {
            if (!ModelState.IsValid) return View(model);
            _context.InvoiceDonations.Add(model);
            _context.SaveChanges();
            TempData["Message"] = "Invoice donation saved.";
            return RedirectToAction(nameof(Details), new { id = model.InvoiceDonationID });
        }
    }
}






