using System.ComponentModel.DataAnnotations;

namespace Gift_of_the_givers.Models
{
    public class Disaster
    {
        [Key]
        public int DisasterID { get; set; }

        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }

        // Emergency-specific details
        public string? EmergencyType { get; set; }

        public string? EmergencyDetails { get; set; }

        public string? Status { get; set; }

        // Location details
        public string? Location { get; set; }

        public string? LocationCity { get; set; }

        public string? LocationRegion { get; set; }

        public string? LocationCountry { get; set; }

        // Dates related to the disaster lifecycle
        public DateTime StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public DateTime? ReportedDate { get; set; }
    }
}


