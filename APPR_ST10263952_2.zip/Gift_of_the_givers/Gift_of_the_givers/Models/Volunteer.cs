using System.ComponentModel.DataAnnotations;

namespace Gift_of_the_givers.Models
{
    public class Volunteer
    {
        [Key]
        public int VolunteerID { get; set; }

        public string FirstName { get; set; } = string.Empty;

        public string LastName { get; set; } = string.Empty;

        public string? Email { get; set; }

        public string? Phone { get; set; }

        public string? Skills { get; set; }

        // Registration & profile
        [DataType(DataType.Date)]
        public DateTime RegistrationDate { get; set; }

        public bool IsActive { get; set; } = true;

        public string? PreferredLocations { get; set; }

        public string? Availability { get; set; }

        public string? Interests { get; set; }

        // Task browsing and tracking summary fields
        public int TasksDueCount { get; set; }

        public int TasksCompletedCount { get; set; }

        public int TotalContributions { get; set; }

        [DataType(DataType.Date)]
        public DateTime? LastContributionDate { get; set; }

        public string? CurrentAssignmentsSummary { get; set; }
    }
}


