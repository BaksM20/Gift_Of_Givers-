using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Gift_of_the_givers.Models
{
    public class Resource
    {
        [Key]
        public int ResourceID { get; set; }

        [ForeignKey("Disaster")]
        [Display(Name = "Disaster")]
        public int? DisasterID { get; set; }

        public Disaster? Disaster { get; set; }

        [Required]
        [MaxLength(200)]
        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be greater than zero.")]
        public int Quantity { get; set; }

        public string? Unit { get; set; }

        // Donation categorization
        public ResourceType Type { get; set; }

        // Food-specific metadata
        public bool IsFoodPerishable { get; set; }

        public DateTime? FoodExpiryDate { get; set; }

        public string? FoodAllergenWarnings { get; set; }

        // Clothing-specific metadata
        public string? ClothingSize { get; set; }

        public string? ClothingCategory { get; set; } // e.g., Men, Women, Children, Unisex

        // Medication-specific metadata
        public string? MedicationDosageForm { get; set; } // e.g., tablet, syrup

        public string? MedicationStrength { get; set; } // e.g., 500mg

        public DateTime? MedicationExpiryDate { get; set; }

        public string? MedicationAllergenWarnings { get; set; }

        // Logistics and tracking
        public string? TrackingCode { get; set; }

        [DataType(DataType.Date)]
        public DateTime? DonationReceivedDate { get; set; }

        public string? AffectedLocation { get; set; }

        public string? ReceivingFacility { get; set; } // facility that received the donation

        public string? DistributingFacility { get; set; } // facility that distributed the donation further

        public string? Notes { get; set; }
    }

    public enum ResourceType
    {
        Unknown = 0,
        Clothes = 1,
        Food = 2,
        Medication = 3
    }
}


