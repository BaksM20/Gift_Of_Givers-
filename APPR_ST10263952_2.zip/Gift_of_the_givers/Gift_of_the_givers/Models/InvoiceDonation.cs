using System.ComponentModel.DataAnnotations;

namespace Gift_of_the_givers.Models
{
    public class InvoiceDonation
    {
        [Key]
        public int InvoiceDonationID { get; set; }

        [Required]
        [MaxLength(200)]
        public string DonorName { get; set; } = string.Empty;

        [EmailAddress]
        public string? DonorEmail { get; set; }

        [MaxLength(50)]
        public string? InvoiceNumber { get; set; }

        [DataType(DataType.Date)]
        public DateTime InvoiceDate { get; set; } = DateTime.Today;

        [Range(0.01, double.MaxValue)]
        public decimal Amount { get; set; }

        [MaxLength(3)]
        public string Currency { get; set; } = "ZAR";

        [MaxLength(500)]
        public string? Notes { get; set; }
    }
}






