using System.ComponentModel.DataAnnotations;

namespace Gift_of_the_givers.Models
{
    public class ProfileViewModel
    {
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        public string? FirstName { get; set; }

        public string? LastName { get; set; }

        [Phone]
        public string? PhoneNumber { get; set; }
    }
}









