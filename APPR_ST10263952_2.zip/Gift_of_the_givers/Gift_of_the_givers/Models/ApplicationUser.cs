using Microsoft.AspNetCore.Identity;

namespace Gift_of_the_givers.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string? FirstName { get; set; }

        public string? LastName { get; set; }
    }
}


