using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Gift_of_the_givers.Models
{
    public enum VolunteerTaskStatus
    {
        Pending = 0,
        Assigned = 1,
        InProgress = 2,
        Completed = 3,
        Cancelled = 4
    }

    public class VolunteerTask
    {
        [Key]
        public int VolunteerTaskID { get; set; }

        [Required]
        [MaxLength(200)]
        public string Title { get; set; } = string.Empty;

        [MaxLength(2000)]
        public string? Description { get; set; }

        public DateTime? ScheduledAt { get; set; }

        public VolunteerTaskStatus Status { get; set; } = VolunteerTaskStatus.Pending;

        public int? VolunteerID { get; set; }

        [ForeignKey(nameof(VolunteerID))]
        public Volunteer? Volunteer { get; set; }
    }
}








